My project is a sports trivia, where the player tests his/her skillset and tries to get as many points as possible. I chose to do sports trivia because that is my biggest strenght in trivia and obviously I want to be good at my own game!
The trivia is multiple choice trivia, where the player has to choose the correct answer.

Project features and instructions:

Firstly the player gets to the welcoming screen, where player can read the rules of the game and when the player is ready to start the game he/she can press the button Play Sports Trivia!.
Then the game begins and for each question the player has 10 seconds to answer. So then the trivia will be fast paced test, where there are not too much time to think about the answer. The timer will be visible to the player.
However if the timer runs out, player will not be able to answer and also the player won´t be getting a point and the trivia moves on the next question. 
There is added a little delay so the player can see better if he/she got the answer right and if the answer is wrong then the player can see more clearly what was the correct answer.
When the player decides to choose his/her answer he/she must press the answer. The correct answer will pop up green and the incorrect answers will pop up red. So eventhough the player chooses the wrong answer, player can still see the correct answer and learn. 
Player can also see while playing that how many questions there are still remaining. For example Question 2/10. 
Player can also see how many points he/she has got during the game and it will automatically update throughout the game.
Finally when the player has answered to all of the questions, the trivia will end and tell what was the players score. It also depends how many points the player gets, that what kind of message the player will receive from the game.
Then the player can restart the game by pressing "Restart The Game".


The questions were taken from https://opentdb.com/api_config.php
I used a bootstrap theme to make a better look for the game also.


